<?php

/**
 * EmployeeMemberDetail form.
 *
 * @package    form
 * @subpackage EmployeeMemberDetail
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 6174 2007-11-27 06:22:40Z fabien $
 */
class EmployeeMemberDetailForm extends BaseEmployeeMemberDetailForm
{
  public function configure()
  {
  }
}