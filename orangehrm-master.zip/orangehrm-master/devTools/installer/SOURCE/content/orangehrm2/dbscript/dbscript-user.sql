INSERT INTO `ohrm_user` VALUES (1, 1, NULL, '?UserName', '?PasswordHash', 0, 1, NULL, NULL, NULL, NULL);
